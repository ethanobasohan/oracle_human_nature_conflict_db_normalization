SELECT count(*) FROM animal_human_conflict;

SELECT count(*) FROM Conflict_Event;

SELECT DISTINCT conservation_status_animal FROM animal_human_conflict;
SELECT DISTINCT conservation_status_diet FROM animal_human_conflict;

INSERT INTO Conservation_Status (status_id, status_name, status_code)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY status_val),
    status_val,
    0
FROM (
    SELECT conservation_status_animal AS status_val 
    FROM animal_human_conflict 
    WHERE conservation_status_animal IS NOT NULL
    UNION
    SELECT conservation_status_diet 
    FROM animal_human_conflict 
    WHERE conservation_status_diet IS NOT NULL
);

SELECT * FROM Conservation_Status;

SELECT DISTINCT reproduction_cycle_speed_animal FROM animal_human_conflict;

INSERT INTO Reproduction_Speed (speed_id, speed_category, speed_level)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY reproduction_cycle_speed_animal),
    reproduction_cycle_speed_animal,
    0
FROM animal_human_conflict
WHERE reproduction_cycle_speed_animal IS NOT NULL;

SELECT * FROM Reproduction_Speed;

SELECT DISTINCT diet_animal FROM animal_human_conflict;

INSERT INTO Diet_Type (diet_id, diet_name, diet_category)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY diet_animal),
    diet_animal,
    'General'
FROM animal_human_conflict
WHERE diet_animal IS NOT NULL;

SELECT * FROM Diet_Type;

SELECT DISTINCT diet_range FROM animal_human_conflict;

INSERT INTO Diet_Range (range_id, range_name, range_type)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY diet_range),
    diet_range,
    'General'
FROM animal_human_conflict
WHERE diet_range IS NOT NULL;

SELECT * FROM Diet_Range;

SELECT DISTINCT human_impact_on_diet FROM animal_human_conflict;

INSERT INTO Impact_Level (impact_id, impact_name, impact_score)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY human_impact_on_diet),
    human_impact_on_diet,
    0
FROM animal_human_conflict
WHERE human_impact_on_diet IS NOT NULL;

SELECT * FROM Impact_Level;

SELECT DISTINCT human_population_in_range FROM animal_human_conflict;

INSERT INTO Population_Level (population_id, population_name, density_score)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY human_population_in_range),
    human_population_in_range,
    0
FROM animal_human_conflict
WHERE human_population_in_range IS NOT NULL;

SELECT * FROM Population_Level;

SELECT DISTINCT number_of_human_settlements FROM animal_human_conflict;

INSERT INTO Settlement_Level (settlement_id, settlement_name, settlement_score)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY number_of_human_settlements),
    number_of_human_settlements,
    0
FROM animal_human_conflict
WHERE number_of_human_settlements IS NOT NULL;

SELECT * FROM Settlement_Level;

SELECT DISTINCT reproduction_rate_diet FROM animal_human_conflict;

INSERT INTO Reproduction_Rate (rate_id, rate_category, rate_value)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY reproduction_rate_diet),
    reproduction_rate_diet,
    0
FROM animal_human_conflict
WHERE reproduction_rate_diet IS NOT NULL;

SELECT DISTINCT human_conflict_mortality_animal FROM animal_human_conflict;

INSERT INTO Mortality_Level (mortality_id, mortality_name, risk_score)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY human_conflict_mortality_animal),
    human_conflict_mortality_animal,
    0
FROM animal_human_conflict
WHERE human_conflict_mortality_animal IS NOT NULL;

SELECT * FROM Mortality_Level;

SELECT DISTINCT peak_season FROM animal_human_conflict;

INSERT INTO Season (season_id, season_name, season_type)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY peak_season),
    peak_season,
    'General'
FROM animal_human_conflict
WHERE peak_season IS NOT NULL;

SELECT * FROM Season;

SELECT DISTINCT conflict_type FROM animal_human_conflict;

INSERT INTO Conflict_Type (conflict_type_id, condition_name, conflict_category)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY conflict_type),
    conflict_type,
    'General'
FROM animal_human_conflict
WHERE conflict_type IS NOT NULL;

SELECT * FROM Conflict_Type;

SELECT DISTINCT PRIMARILY_LOCATION FROM animal_human_conflict;

INSERT INTO Location (location_id, primary_location, country, sub_region)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY PRIMARILY_LOCATION),
    PRIMARILY_LOCATION,
    CASE 
        WHEN PRIMARILY_LOCATION IN ('East Africa', 'Sub-Saharan Africa', 'Southern Africa', 'Central Africa') 
        THEN 'Africa'
        WHEN PRIMARILY_LOCATION = 'India' 
        THEN 'India'
        ELSE PRIMARILY_LOCATION
    END,
    'N/A'
FROM animal_human_conflict
WHERE PRIMARILY_LOCATION IS NOT NULL;

SELECT * FROM Location;

SELECT DISTINCT species_name FROM animal_human_conflict;

INSERT INTO Animal_Species (species_id, species_name, scientific_name, Conservation_Status_status_id, Reproduction_Speed_speed_id)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY s.species_name),
    s.species_name,
    'Unknown',
    cs.status_id,
    rs.speed_id
FROM animal_human_conflict s
LEFT JOIN Conservation_Status cs ON cs.status_name = s.conservation_status_animal
LEFT JOIN Reproduction_Speed rs ON rs.speed_category = s.reproduction_cycle_speed_animal
WHERE s.species_name IS NOT NULL
AND cs.status_id IS NOT NULL
AND rs.speed_id IS NOT NULL;

SELECT * FROM Animal_Species;

SELECT DISTINCT specific_hotspot, PRIMARILY_LOCATION FROM animal_human_conflict;

INSERT INTO Specific_Hotspot (hotspot_id, hotspot_name, Location_location_id)
SELECT DISTINCT 
    DENSE_RANK() OVER (ORDER BY s.specific_hotspot),
    s.specific_hotspot,
    l.location_id
FROM animal_human_conflict s
JOIN Location l ON l.primary_location = s.PRIMARILY_LOCATION
WHERE s.specific_hotspot IS NOT NULL;

SELECT * FROM Specific_Hotspot;

SELECT count(*) FROM Conservation_Status;
SELECT count(*) FROM Reproduction_Speed;
SELECT count(*) FROM Diet_Type;
SELECT count(*) FROM Diet_Range;
SELECT count(*) FROM Impact_Level;
SELECT count(*) FROM Population_Level;
SELECT count(*) FROM Settlement_Level;
SELECT count(*) FROM Mortality_Level;
SELECT count(*) FROM Season;
SELECT count(*) FROM Conflict_Type;
SELECT count(*) FROM Location;
SELECT count(*) FROM Specific_Hotspot;
SELECT count(*) FROM Animal_Species;

INSERT INTO Conflict_Event (
    event_id,
    observation_date,
    year_of_highest_kills,
    Animal_Species_species_id,
    Specific_Hotspot_hotspot_id,
    Conflict_Type_conflict_type_id,
    Conservation_Status_status_id,
    Reproduction_Speed_speed_id,
    Diet_Type_diet_id,
    Diet_Range_range_id,
    Impact_Level_impact_id,
    Population_Level_population_id,
    Settlement_Level_settlement_id,
    Mortality_Level_mortality_id,
    Season_season_id
)
SELECT 
    ROWNUM,
    TO_DATE(s.observation_date, 'DD-MON-YY'),
    TO_NUMBER(s.year_of_highest_kills),
    sp.species_id,
    hs.hotspot_id,
    ct.conflict_type_id,
    cs1.status_id,
    rs.speed_id,
    dt.diet_id,
    dr.range_id,
    il.impact_id,
    pl.population_id,
    sl.settlement_id,
    ml.mortality_id,
    se.season_id
FROM animal_human_conflict s
LEFT JOIN Animal_Species sp ON sp.species_name = s.species_name
LEFT JOIN Specific_Hotspot hs ON hs.hotspot_name = s.specific_hotspot
LEFT JOIN Conflict_Type ct ON ct.condition_name = s.conflict_type
LEFT JOIN Conservation_Status cs1 ON cs1.status_name = s.conservation_status_animal
LEFT JOIN Reproduction_Speed rs ON rs.speed_category = s.reproduction_cycle_speed_animal
LEFT JOIN Diet_Type dt ON dt.diet_name = s.diet_animal
LEFT JOIN Diet_Range dr ON dr.range_name = s.diet_range
LEFT JOIN Impact_Level il ON il.impact_name = s.human_impact_on_diet
LEFT JOIN Population_Level pl ON pl.population_name = s.human_population_in_range
LEFT JOIN Conservation_Status cs2 ON cs2.status_name = s.conservation_status_diet
LEFT JOIN Settlement_Level sl ON sl.settlement_name = s.number_of_human_settlements
LEFT JOIN Mortality_Level ml ON ml.mortality_name = s.human_conflict_mortality_animal
LEFT JOIN Season se ON se.season_name = s.peak_season
WHERE s.observation_date IS NOT NULL;

COMMIT;

SELECT count(*) FROM animal_human_conflict;

SELECT count(*) FROM Conflict_Event;

SELECT l.primary_location, count(*) 
FROM Conflict_Event ce
JOIN Specific_Hotspot hs ON hs.hotspot_id = ce.Specific_Hotspot_hotspot_id
JOIN Location l ON l.location_id = hs.Location_location_id
GROUP BY l.primary_location
ORDER BY count(*) DESC;
