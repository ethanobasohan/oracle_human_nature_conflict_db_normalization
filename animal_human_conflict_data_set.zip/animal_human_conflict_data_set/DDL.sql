-- Created by Redgate Data Modeler (https://datamodeler.redgate-platform.com)
-- Last modification date: 2026-08-27 18:44:12.758

-- tables
-- Table: Animal_Species
CREATE TABLE Animal_Species (
    species_id NUMBER(10)  NOT NULL,
    species_name VARCHAR2(100)  NOT NULL,
    scientific_name VARCHAR2(100)  NOT NULL,
    Conservation_Status_status_id NUMBER(10)  NOT NULL,
    Reproduction_Speed_speed_id NUMBER(10)  NOT NULL,
    CONSTRAINT Animal_Species_pk PRIMARY KEY (species_id)
) ;

-- Table: Conflict_Event
CREATE TABLE Conflict_Event (
    event_id NUMBER(10)  NOT NULL,
    observation_date DATE  NOT NULL,
    year_of_highest_kills VARCHAR2(100)  NOT NULL,
    Animal_Species_species_id NUMBER(10)  NOT NULL,
    Specific_Hotspot_hotspot_id NUMBER(10)  NOT NULL,
    Conflict_Type_conflict_type_id NUMBER(10)  NOT NULL,
    Conservation_Status_status_id NUMBER(10)  NOT NULL,
    Reproduction_Speed_speed_id NUMBER(10)  NOT NULL,
    Diet_Type_diet_id NUMBER(10)  NOT NULL,
    Diet_Range_range_id NUMBER(10)  NOT NULL,
    Impact_Level_impact_id NUMBER(10)  NOT NULL,
    Population_Level_population_id NUMBER(10)  NOT NULL,
    Settlement_Level_settlement_id NUMBER(10)  NOT NULL,
    Mortality_Level_mortality_id NUMBER(10)  NOT NULL,
    Season_season_id NUMBER(10)  NOT NULL,
    CONSTRAINT Conflict_Event_pk PRIMARY KEY (event_id)
) ;

-- Table: Conflict_Type
CREATE TABLE Conflict_Type (
    conflict_type_id NUMBER(10)  NOT NULL,
    condition_name VARCHAR2(100)  NOT NULL,
    conflict_category VARCHAR2(100)  NOT NULL,
    CONSTRAINT Conflict_Type_pk PRIMARY KEY (conflict_type_id)
) ;

-- Table: Conservation_Status
CREATE TABLE Conservation_Status (
    status_id NUMBER(10)  NOT NULL,
    status_name VARCHAR2(100)  NOT NULL,
    status_code NUMBER(10)  NOT NULL,
    CONSTRAINT Conservation_Status_pk PRIMARY KEY (status_id)
) ;

-- Table: Diet_Range
CREATE TABLE Diet_Range (
    range_id NUMBER(10)  NOT NULL,
    range_name VARCHAR2(100)  NOT NULL,
    range_type VARCHAR2(100)  NOT NULL,
    CONSTRAINT Diet_Range_pk PRIMARY KEY (range_id)
) ;

-- Table: Diet_Type
CREATE TABLE Diet_Type (
    diet_id NUMBER(10)  NOT NULL,
    diet_name VARCHAR2(100)  NOT NULL,
    diet_category VARCHAR2(100)  NOT NULL,
    CONSTRAINT Diet_Type_pk PRIMARY KEY (diet_id)
) ;

-- Table: Impact_Level
CREATE TABLE Impact_Level (
    impact_id NUMBER(10)  NOT NULL,
    impact_name VARCHAR2(100)  NOT NULL,
    impact_score VARCHAR2(100)  NOT NULL,
    CONSTRAINT Impact_Level_pk PRIMARY KEY (impact_id)
) ;

-- Table: Location
CREATE TABLE Location (
    location_id NUMBER(10)  NOT NULL,
    region_name VARCHAR2(100)  NOT NULL,
    country VARCHAR2(100)  NOT NULL,
    sub_region VARCHAR2(30)  NOT NULL,
    CONSTRAINT Location_pk PRIMARY KEY (location_id)
) ;

-- Table: Mortality_Level
CREATE TABLE Mortality_Level (
    mortality_id NUMBER(10)  NOT NULL,
    mortality_name VARCHAR2(100)  NOT NULL,
    risk_score VARCHAR2(100)  NOT NULL,
    CONSTRAINT Mortality_Level_pk PRIMARY KEY (mortality_id)
) ;

-- Table: Population_Level
CREATE TABLE Population_Level (
    population_id NUMBER(10)  NOT NULL,
    population_name VARCHAR2(100)  NOT NULL,
    density_score VARCHAR2(100)  NOT NULL,
    CONSTRAINT Population_Level_pk PRIMARY KEY (population_id)
) ;

-- Table: Reproduction_Rate
CREATE TABLE Reproduction_Rate (
    rate_id NUMBER(10)  NOT NULL,
    rate_category VARCHAR2(100)  NOT NULL,
    rate_value VARCHAR2(100)  NOT NULL,
    Conflict_Event_event_id NUMBER(10)  NOT NULL,
    CONSTRAINT Reproduction_Rate_pk PRIMARY KEY (rate_id)
) ;

-- Table: Reproduction_Speed
CREATE TABLE Reproduction_Speed (
    speed_id NUMBER(10)  NOT NULL,
    speed_category VARCHAR2(100)  NOT NULL,
    speed_level VARCHAR2(100)  NOT NULL,
    CONSTRAINT Reproduction_Speed_pk PRIMARY KEY (speed_id)
) ;

-- Table: Season
CREATE TABLE Season (
    season_id NUMBER(10)  NOT NULL,
    season_name VARCHAR2(100)  NOT NULL,
    season_type VARCHAR2(100)  NOT NULL,
    CONSTRAINT Season_pk PRIMARY KEY (season_id)
) ;

-- Table: Settlement_Level
CREATE TABLE Settlement_Level (
    settlement_id NUMBER(10)  NOT NULL,
    settlement_name VARCHAR2(100)  NOT NULL,
    settlement_score VARCHAR2(100)  NOT NULL,
    CONSTRAINT Settlement_Level_pk PRIMARY KEY (settlement_id)
) ;

-- Table: Specific_Hotspot
CREATE TABLE Specific_Hotspot (
    hotspot_id NUMBER(10)  NOT NULL,
    hotspot_name VARCHAR2(100)  NOT NULL,
    Location_location_id NUMBER(10)  NOT NULL,
    CONSTRAINT Specific_Hotspot_pk PRIMARY KEY (hotspot_id)
) ;

-- foreign keys
-- Reference: Animal_Species_Conservation_Status (table: Animal_Species)
ALTER TABLE Animal_Species ADD CONSTRAINT Animal_Species_Conservation_Status
    FOREIGN KEY (Conservation_Status_status_id)
    REFERENCES Conservation_Status (status_id);

-- Reference: Animal_Species_Reproduction_Speed (table: Animal_Species)
ALTER TABLE Animal_Species ADD CONSTRAINT Animal_Species_Reproduction_Speed
    FOREIGN KEY (Reproduction_Speed_speed_id)
    REFERENCES Reproduction_Speed (speed_id);

-- Reference: Conflict_Event_Animal_Species (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Animal_Species
    FOREIGN KEY (Animal_Species_species_id)
    REFERENCES Animal_Species (species_id);

-- Reference: Conflict_Event_Conflict_Type (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Conflict_Type
    FOREIGN KEY (Conflict_Type_conflict_type_id)
    REFERENCES Conflict_Type (conflict_type_id);

-- Reference: Conflict_Event_Conservation_Status (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Conservation_Status
    FOREIGN KEY (Conservation_Status_status_id)
    REFERENCES Conservation_Status (status_id);

-- Reference: Conflict_Event_Diet_Range (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Diet_Range
    FOREIGN KEY (Diet_Range_range_id)
    REFERENCES Diet_Range (range_id);

-- Reference: Conflict_Event_Diet_Type (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Diet_Type
    FOREIGN KEY (Diet_Type_diet_id)
    REFERENCES Diet_Type (diet_id);

-- Reference: Conflict_Event_Impact_Level (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Impact_Level
    FOREIGN KEY (Impact_Level_impact_id)
    REFERENCES Impact_Level (impact_id);

-- Reference: Conflict_Event_Mortality_Level (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Mortality_Level
    FOREIGN KEY (Mortality_Level_mortality_id)
    REFERENCES Mortality_Level (mortality_id);

-- Reference: Conflict_Event_Population_Level (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Population_Level
    FOREIGN KEY (Population_Level_population_id)
    REFERENCES Population_Level (population_id);

-- Reference: Conflict_Event_Reproduction_Speed (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Reproduction_Speed
    FOREIGN KEY (Reproduction_Speed_speed_id)
    REFERENCES Reproduction_Speed (speed_id);

-- Reference: Conflict_Event_Season (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Season
    FOREIGN KEY (Season_season_id)
    REFERENCES Season (season_id);

-- Reference: Conflict_Event_Settlement_Level (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Settlement_Level
    FOREIGN KEY (Settlement_Level_settlement_id)
    REFERENCES Settlement_Level (settlement_id);

-- Reference: Conflict_Event_Specific_Hotspot (table: Conflict_Event)
ALTER TABLE Conflict_Event ADD CONSTRAINT Conflict_Event_Specific_Hotspot
    FOREIGN KEY (Specific_Hotspot_hotspot_id)
    REFERENCES Specific_Hotspot (hotspot_id);

-- Reference: Reproduction_Rate_Conflict_Event (table: Reproduction_Rate)
ALTER TABLE Reproduction_Rate ADD CONSTRAINT Reproduction_Rate_Conflict_Event
    FOREIGN KEY (Conflict_Event_event_id)
    REFERENCES Conflict_Event (event_id);

-- Reference: Specific_Hotspot_Location (table: Specific_Hotspot)
ALTER TABLE Specific_Hotspot ADD CONSTRAINT Specific_Hotspot_Location
    FOREIGN KEY (Location_location_id)
    REFERENCES Location (location_id);

-- End of file.

